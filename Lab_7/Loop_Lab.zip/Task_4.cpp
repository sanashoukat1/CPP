//sum of first 5 numbers
#include<iostream>
using namespace std;
int main()
{
    int n,sum=0;
    for(n=1;n<=5;n++)
        sum=sum+n;
    cout<<"Sum= "<<sum;  
    return 0; 
}