// Fibonacci series
#include<iostream>
using namespace std;
int main()
{
    int n,i;
    cout<<"Enter the length of Fibonacci series."<<endl;
    cin>>n;
    for(i=0;i<=n;i++)
        cout<<"\t"<<i;
    return 0;
}