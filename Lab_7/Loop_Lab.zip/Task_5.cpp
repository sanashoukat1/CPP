// sum of first 100 natural numbers
#include<iostream>
using namespace std;
int main()
{
    int i,sum=0;
    for(i=1;i<=100;i++)
        sum=sum+i;
    cout<<"Sum= "<<sum;    
    return 0;
}