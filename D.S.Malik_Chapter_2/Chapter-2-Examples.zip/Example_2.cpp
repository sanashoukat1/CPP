#include<iostream>
using namespace std;
int main()
{
    int inches,feet,inch;
    inches=100;
    feet=inches/12;
    inch=inches%12;
    cout<<inches<<" inch(es)= "<<feet<<" feet(foot) and "<<inch<<" inch(es)";
    
}




































 