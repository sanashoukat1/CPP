#include<iostream>
using namespace std;
int main()
{
    int array[5];
    cout<<"Enter valve of 1st element: "<<endl;
    cout<<array[0];
    cout<<"Enter valve of 2nd element: "<<endl;
    cout<<array[1];
    cout<<"Enter valve of 3rd element: "<<endl;
    cout<<array[2];
    cout<<"Enter valve of 4th element: "<<endl;
    cout<<array[3];
    cout<<"Enter valve of 5th element: "<<endl;
    cout<<array[4];
    cout<<"1st element at location [0]="<<array[0]<<endl;
    cout<<"last element at location [4]="<<array[4]<<endl;
    return 0;
}