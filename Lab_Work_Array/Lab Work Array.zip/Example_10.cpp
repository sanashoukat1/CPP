#include <iostream>
using namespace std;
int main()
{
    char pk[]="Pakistan";
    cout<<"at 0  location="<<pk[0]<<endl;
    cout<<"at 1  location="<<pk[1]<<endl;
    cout<<"at 2  location="<<pk[2]<<endl;
    cout<<"at 3  location="<<pk[3]<<endl;
    cout<<"at 4  location="<<pk[4]<<endl;
    cout<<"at 5  location="<<pk[5]<<endl;
    cout<<"at 6  location="<<pk[6]<<endl;
    cout<<"at 7  location="<<pk[7]<<endl;
    return 0;
}