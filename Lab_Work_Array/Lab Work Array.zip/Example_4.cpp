#include<iostream>
using namespace std;
int main()
{
    int numbers[5];
    cout<<"Eneter 5 numbers: "<<endl;
    for(int i=0;i<5;i++)
        cin>>numbers[i];
    return 0;
}