#include<iostream>
using namespace std;
int main()
{
    char array[6]="hello";
    for(int i=4;i>=0;i--)
      {  
        cout<<array[i];
      }
    return 0;
}